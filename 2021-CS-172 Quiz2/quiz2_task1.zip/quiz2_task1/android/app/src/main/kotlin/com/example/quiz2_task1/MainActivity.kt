package com.example.quiz2_task1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
